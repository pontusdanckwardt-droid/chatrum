# Invite Chat för Render

En enkel, anonym chatt där personer kan skapa ett rum och dela en 8-teckens invite-kod. Ingen inloggning krävs.

## Deploya på Render

1. Ladda ner och packa upp ZIP-filen.
2. Ladda upp mappen till ett nytt GitHub-repo.
3. I Render: **New → Web Service** och välj repot.
4. Runtime: **Node**
5. Build Command: `npm install`
6. Start Command: `npm start`
7. Skapa webbtjänsten.

## Kör lokalt

```bash
npm install
npm start
```

Öppna `http://localhost:3000`.

## Datalagring

Meddelanden sparas i SQLite. På Renders gratisnivå kan data försvinna när tjänsten startas om. För permanent lagring, lägg till en Persistent Disk och sätt `DATA_DIR` till dess monteringsväg, till exempel `/opt/render/data`.
