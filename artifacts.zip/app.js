const $ = (id) => document.getElementById(id);
let roomCode = "";
let lastId = 0;
let timer = null;

function showError(text) { $("error").textContent = text; }

async function createRoom() {
  showError("");
  const name = $("name").value.trim() || "Anonym";
  const response = await fetch("/api/rooms", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name })
  });
  const data = await response.json();
  if (!response.ok) return showError(data.error || "Kunde inte skapa rummet.");
  openRoom(data.code, name);
}

async function joinRoom() {
  showError("");
  const code = $("code").value.trim().toUpperCase();
  if (code.length !== 8) return showError("Invite-koden måste vara 8 tecken.");
  const response = await fetch(`/api/rooms/${code}`);
  const data = await response.json();
  if (!response.ok) return showError(data.error || "Kunde inte öppna rummet.");
  openRoom(code, $("name").value.trim() || "Anonym");
}

function openRoom(code, name) {
  roomCode = code;
  lastId = 0;
  $("start").classList.add("hidden");
  $("chat").classList.remove("hidden");
  $("roomCode").textContent = code;
  $("messages").innerHTML = "";
  $("message").focus();
  localStorage.setItem("inviteChatName", name);
  localStorage.setItem("inviteChatRoom", code);
  loadMessages();
  clearInterval(timer);
  timer = setInterval(loadMessages, 2000);
}

async function loadMessages() {
  if (!roomCode) return;
  const response = await fetch(`/api/rooms/${roomCode}/messages?after=${lastId}`);
  if (!response.ok) return;
  const data = await response.json();
  for (const message of data.messages) {
    addMessage(message);
    lastId = Math.max(lastId, message.id);
  }
  if (data.messages.length) $("messages").scrollTop = $("messages").scrollHeight;
}

function addMessage(message) {
  const div = document.createElement("div");
  const system = message.sender === "System";
  div.className = `message${system ? " system" : ""}`;
  const time = new Date(message.created_at).toLocaleTimeString("sv-SE", { hour: "2-digit", minute: "2-digit" });
  div.innerHTML = `<div class="sender"></div><div class="body"></div>`;
  div.querySelector(".sender").textContent = system ? message.sender : `${message.sender} · ${time}`;
  div.querySelector(".body").textContent = message.body;
  $("messages").appendChild(div);
}

async function sendMessage(event) {
  event.preventDefault();
  const body = $("message").value.trim();
  if (!body || !roomCode) return;
  const sender = localStorage.getItem("inviteChatName") || "Anonym";
  const response = await fetch(`/api/rooms/${roomCode}/messages`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ sender, body })
  });
  if (response.ok) {
    $("message").value = "";
    await loadMessages();
  }
}

$("create").addEventListener("click", createRoom);
$("join").addEventListener("click", joinRoom);
$("form").addEventListener("submit", sendMessage);
$("code").addEventListener("keydown", (event) => { if (event.key === "Enter") joinRoom(); });
$("copy").addEventListener("click", async () => {
  await navigator.clipboard.writeText(roomCode);
  $("copy").textContent = "Kopierad!";
  setTimeout(() => $("copy").textContent = "Kopiera kod", 1500);
});

const savedRoom = localStorage.getItem("inviteChatRoom");
if (savedRoom) $("code").value = savedRoom;
