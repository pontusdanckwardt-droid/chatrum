const express = require("express");
const path = require("path");
const fs = require("fs");
const Database = require("better-sqlite3");

const app = express();
app.use(express.json());

const dataDir = process.env.DATA_DIR || path.join(__dirname, "data");
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, "chat.db"));
db.pragma("journal_mode = WAL");

db.exec(`
  CREATE TABLE IF NOT EXISTS rooms (
    id TEXT PRIMARY KEY,
    created_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    room_id TEXT NOT NULL,
    sender TEXT NOT NULL,
    body TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    FOREIGN KEY (room_id) REFERENCES rooms(id)
  );
`);

const makeCode = () => {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for (let i = 0; i < 8; i++) code += alphabet[Math.floor(Math.random() * alphabet.length)];
  return code;
};

app.post("/api/rooms", (req, res) => {
  const name = String(req.body?.name || "").trim().slice(0, 30) || "Anonym";
  const id = makeCode();
  db.prepare("INSERT INTO rooms (id, created_at) VALUES (?, ?)").run(id, Date.now());
  db.prepare("INSERT INTO messages (room_id, sender, body, created_at) VALUES (?, ?, ?, ?)")
    .run(id, "System", `${name} skapade rummet. Dela koden ${id} för att chatta.`, Date.now());
  res.json({ code: id, name });
});

app.get("/api/rooms/:code", (req, res) => {
  const room = db.prepare("SELECT id FROM rooms WHERE id = ?").get(req.params.code.toUpperCase());
  if (!room) return res.status(404).json({ error: "Rummet hittades inte." });
  res.json({ code: room.id });
});

app.get("/api/rooms/:code/messages", (req, res) => {
  const room = db.prepare("SELECT id FROM rooms WHERE id = ?").get(req.params.code.toUpperCase());
  if (!room) return res.status(404).json({ error: "Rummet hittades inte." });
  const after = Number(req.query.after || 0);
  const rows = db.prepare(
    "SELECT id, sender, body, created_at FROM messages WHERE room_id = ? AND id > ? ORDER BY id ASC LIMIT 200"
  ).all(room.id, after);
  res.json({ messages: rows });
});

app.post("/api/rooms/:code/messages", (req, res) => {
  const room = db.prepare("SELECT id FROM rooms WHERE id = ?").get(req.params.code.toUpperCase());
  if (!room) return res.status(404).json({ error: "Rummet hittades inte." });
  const sender = String(req.body?.sender || "").trim().slice(0, 30) || "Anonym";
  const body = String(req.body?.body || "").trim().slice(0, 1000);
  if (!body) return res.status(400).json({ error: "Meddelandet får inte vara tomt." });
  const info = db.prepare(
    "INSERT INTO messages (room_id, sender, body, created_at) VALUES (?, ?, ?, ?)"
  ).run(room.id, sender, body, Date.now());
  const message = db.prepare("SELECT id, sender, body, created_at FROM messages WHERE id = ?").get(info.lastInsertRowid);
  res.status(201).json({ message });
});

app.use(express.static(path.join(__dirname, "public")));
app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Invite Chat körs på port ${port}`));
